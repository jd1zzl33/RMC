package fileutil

import (
    "archive/zip"
    "io"
    "io/ioutil"
    "os"
    "path/filepath"
)

// CreateFile creates a file with the given content.
func CreateFile(path string) *os.File {
    file, err := os.Create(path)
    if err != nil {
        // In a real app, handle this error. For now, we just return nil.
        return nil
    }
    return file
}

// Zip creates a zip archive of a source folder.
func Zip(source, target string) error {
    zipfile, err := os.Create(target)
    if err != nil {
        return err
    }
    defer zipfile.Close()

    archive := zip.NewWriter(zipfile)
    defer archive.Close()

    return filepath.Walk(source, func(path string, info os.FileInfo, err error) error {
        if err != nil {
            return err
        }
        header, err := zip.FileInfoHeader(info)
        if err != nil {
            return err
        }

        // Adjust header name to be relative to the source directory
        header.Name, err = filepath.Rel(source, path)
        if err != nil {
            return err
        }
        
        if info.IsDir() {
            header.Name += "/"
        }

        header.Method = zip.Deflate

        writer, err := archive.CreateHeader(header)
        if err != nil {
            return err
        }

        if info.IsDir() {
            return nil
        }

        file, err := os.Open(path)
        if err != nil {
            return err
        }
        defer file.Close()
        _, err = io.Copy(writer, file)
        return err
    })
}

// FindFiles recursively finds all files matching a pattern in a directory.
func FindFiles(root, pattern string) ([]string, error) {
    var matches []string
    err := filepath.Walk(root, func(path string, info os.FileInfo, err error) error {
        if err != nil {
            return err
        }
        if info.IsDir() {
            return nil
        }
        if matched, _ := filepath.Match(pattern, filepath.Base(path)); matched {
            matches = append(matches, path)
        }
        return nil
    })
    return matches, err
}

// ReadFile reads the entire content of a file.
func ReadFile(path string) ([]byte, error) {
    return ioutil.ReadFile(path)
}