package hardware

import (
    "os"
    "os/exec"
    "runtime"
    "strings"
)

// GetUsers returns a list of user profile directories on Windows.
func GetUsers() []string {
    var users []string
    if runtime.GOOS == "windows" {
        userProfilesDir := "C:\\Users"
        entries, err := os.ReadDir(userProfilesDir)
        if err != nil {
            return users
        }
        for _, entry := range entries {
            if entry.IsDir() && entry.Name() != "Public" && entry.Name() != "Default" && !strings.HasPrefix(entry.Name(), ".") {
                users = append(users, strings.Join([]string{userProfilesDir, entry.Name()}, "\\"))
            }
        }
    }
    return users
}

// GetMachineID attempts to get a unique ID for the machine.
func GetMachineID() (string, error) {
    var cmd *exec.Cmd
    
    switch runtime.GOOS {
    case "windows":
        cmd = exec.Command("wmic", "baseboard", "get", "serialnumber")
    case "linux":
        return readFile("/etc/machine-id")
    case "darwin":
        cmd = exec.Command("system_profiler", "SPHardwareDataType")
    default:
        return "unknown_os", nil
    }

    if cmd != nil {
        output, err := cmd.CombinedOutput()
        if err != nil {
            return "", err
        }
        return strings.TrimSpace(string(output)), nil
    }

    return "unknown_id", nil
}

// Helper function to read a file
func readFile(path string) (string, error) {
    data, err := os.ReadFile(path)
    if err != nil {
        return "", err
    }
    return strings.TrimSpace(string(data)), nil
}