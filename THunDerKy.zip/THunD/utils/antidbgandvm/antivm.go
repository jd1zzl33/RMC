package AntiDebugVMAnalysis

func Check() {
	AntiVMCheckAndExit()
}
